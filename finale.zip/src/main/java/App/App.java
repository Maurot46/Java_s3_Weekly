package App;

import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import App.model.Catalogo;
import App.model.Libro;
import App.model.Periodicita;
import App.model.Prestito;
import App.model.Riviste;
import App.model.Utenti;
import App.model.DAO.LibroDAO;
import App.model.DAO.RivistaDAO;
import App.model.DAO.UtenteDAO;

public class App {
	private static final String persistenceUnit = "BibliotecaDB";
	private static final EntityManagerFactory emf = Persistence.createEntityManagerFactory(persistenceUnit);

	public static void main(String[] args) {
		
		//Libro libro = addBookToCatalog();
		//Riviste rivista = addRivistaToCatalog();
		//Utenti utente = addUser();
		//removeBook(456342456);
		//int isbn = 456342455;
	    //int userCardNumber = 424575;
	    //Date data_inizio = new Date();
	    //addBookOrMagazineToLoan(isbn, userCardNumber, data_inizio);
		findUsingIsbn(456342455);
		//findFromYear(LocalDate.of(2023,01,27));
		findFromAutore("Me Stesso");
		findByTitle("Il Castello Errante");
		
	}
	//Libri-----------------------------------------------------
	 public static Libro addBookToCatalog() {
	        Libro libro = new Libro();
	        libro.setIsbn(456342455);
	        libro.setAutore("Me Stesso");
	        libro.setGenere("Fantasy");
	        libro.setNumeroPagine(100);
	        libro.setTitolo("Il Castello Errante");
	        libro.setAnnoPubblicazione(new Date());
	        LibroDAO libroDAO = new LibroDAO();
	        libroDAO.save(libro);
	        return libro;
	 }
	 public static Libro removeBook(long isbn) {
		    EntityManager em = emf.createEntityManager();
		    em.getTransaction().begin();
		    Libro book = em.find(Libro.class, isbn);
		    if(book != null) {
		        em.remove(book);
		    }
		    em.getTransaction().commit();
		    em.close();
			return null;
	}
	 //Riviste-----------------------------------------------------
	 public static Riviste addRivistaToCatalog() {
	        Riviste rivista = new Riviste();
	        rivista.setIsbn(456342456);
	        rivista.setNumeroPagine(25);
	        rivista.setTitolo("Vanity Fair");
	        rivista.setPeriodicita(Periodicita.SETTIMANALE);
	        rivista.setAnnoPubblicazione(new Date());
	        RivistaDAO rivistaDAO = new RivistaDAO();
	        rivistaDAO.save(rivista);
	        return rivista;
	 }
	 public static Riviste removeRivista(long isbn) {
		    EntityManager em = emf.createEntityManager();
		    em.getTransaction().begin();
		    Riviste rivista = em.find(Riviste.class, isbn);
		    if(rivista != null) {
		        em.remove(rivista);
		    }
		    em.getTransaction().commit();
		    em.close();
			return null;
	}
	 //Utenti-----------------------------------------------------------------
	 public static Utenti addUser() {
		 Utenti utente = new Utenti();
		 utente.setNome("Mario");
		 utente.setCognome("Rossi");
		 utente.setNumeroDiTessera(424575);
		 utente.setAnnoDiNascita(LocalDate.of(1989,01,01));
		 utente.setPrestiti(null);
		 UtenteDAO utenteDAO = new UtenteDAO();
		 utenteDAO.save(utente);
		 return utente;
		 
	 }
	 private static LocalDate LocalDate(int i) {
		// TODO Auto-generated method stub
		return null;
	}
	//Metodi----------------------------------------------
	 public static Catalogo findUsingIsbn(long isbn) {
		 EntityManager em = emf.createEntityManager();
		 em.getTransaction().begin();
		 Query query = em.createNamedQuery("searchByISBN");
		 query.setParameter("ISBN", isbn);
		 List<Libro> books = query.getResultList();
		 System.out.println(books);
		 em.getTransaction().commit();
		 em.close();
		 return null;
	 }
	 public static Catalogo findFromYear(Date data) {
		 EntityManager em = emf.createEntityManager();
		 em.getTransaction().begin();
		 Query query = em.createNamedQuery("searchByYear");
		 query.setParameter("year", data);
		 List<Libro> books = query.getResultList();
		 System.out.println(books);
		 em.getTransaction().commit();
		 em.close();
		 return null;
	 }
	 public static Catalogo findFromAutore(String autore) {
		 EntityManager em = emf.createEntityManager();
		 try {
			 em.getTransaction().begin();
			 Query query = em.createNamedQuery("searchByAuthor");
			 query.setParameter("author", autore);
			 List<Libro> books = query.getResultList();
			 System.out.println(books);
			 em.getTransaction().commit();
		 }catch(Exception e) {
			 System.out.println("OPS! Sembra che tu abbia inserito un nome incorretto");
		 }finally {
			 em.close();
		 }
		 return null;
	 }
	 public static Catalogo findByTitle(String titolo) {
		 EntityManager em = emf.createEntityManager();
		 em.getTransaction().begin();
		 Query query = em.createNamedQuery("searchByTitle");
		 query.setParameter("title", titolo);
		 List<Libro> books = query.getResultList();
		 System.out.println(books);
		 em.getTransaction().commit();
		 em.close();
		 return null;
	 }
	 public static Prestito addBookOrMagazineToLoan(long isbn, int numeroDiTessera, Date data_inizio) {
	        // get entity manager factory
	        EntityManagerFactory emf = Persistence.createEntityManagerFactory("BibliotecaDB");
	        // create an entity manager
	        EntityManager em = emf.createEntityManager();
	        //start transaction
	        em.getTransaction().begin();
	        // find the user by card number
	        Utenti user = em.find(Utenti.class, numeroDiTessera);
	        // find the book or magazine by ISBN
	        Object bookOrMagazine = em.find(Libro.class, isbn);
	        if(bookOrMagazine == null)
	            bookOrMagazine = em.find(Riviste.class, isbn);
	        // calculate the end date
	        Calendar cal = Calendar.getInstance();
	        cal.setTime(data_inizio);
	        cal.add(Calendar.DATE, 30);
	        Date endDate = cal.getTime();
	        // create new loan with given attributes
	        Prestito loan = new Prestito();
	        loan.setUtenti(user);
	        loan.setOggetto((Catalogo) bookOrMagazine);
	        loan.setDataInizio(data_inizio);
	        loan.setDataRestituzionePrevista(cal);
	        loan.setDataRestituzioneEffettiva(LocalDate.of(2023, 02, 18));
	        // persist the loan
	        em.persist(loan);
	        // commit transaction
	        em.getTransaction().commit();
	        //close entity manager
	        em.close();
			return loan;
	    }
}
