package App.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@NoArgsConstructor
@Getter
@Setter
public class Libro extends Catalogo {
	private String autore;
	private String genere;
	public Libro(long isbn, String titolo, Date annopubblicazione, int numeroPagine, String autore, String genere) {
		super(isbn, titolo, annopubblicazione, numeroPagine);
		this.autore = autore;
		this.genere = genere;
	}
	
}
