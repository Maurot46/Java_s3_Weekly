package App.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "riviste")
@NoArgsConstructor
@Getter
@Setter
public class Riviste extends Catalogo {
	@Enumerated(EnumType.STRING)
	private Periodicita periodicita;

	public Riviste(long isbn, String titolo, Date annopubblicazione, int numeroPagine, Periodicita periodicita) {
		super(isbn, titolo, annopubblicazione, numeroPagine);
		this.periodicita = periodicita;
	}
	
}
