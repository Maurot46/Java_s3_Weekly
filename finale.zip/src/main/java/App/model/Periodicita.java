package App.model;

public enum Periodicita {
	SETTIMANALE,
	MENSILE,
	ANNUALE
}
