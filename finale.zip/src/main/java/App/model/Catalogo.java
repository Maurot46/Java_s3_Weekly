package App.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
@NoArgsConstructor
@Getter
@Setter
@ToString
@NamedQueries({
	@NamedQuery(name = "searchByISBN", query = "SELECT b FROM Libro b WHERE b.isbn = :ISBN"),
    @NamedQuery(name = "searchByYear", query = "SELECT b FROM Libro b WHERE b.annoPubblicazione = :year"),
    @NamedQuery(name = "searchByAuthor", query = "SELECT b FROM Libro b WHERE b.autore = :author"),
    @NamedQuery(name = "searchByTitle", query = "SELECT b FROM Libro b WHERE b.titolo LIKE :title"),
    @NamedQuery(name = "searchByUser", query = "SELECT l FROM Prestito l WHERE l.utenti.numeroDiTessera = :cardNumber and l.dataRestituzioneEffettiva is null"),
    @NamedQuery(name = "searchByExpiredLoan", query = "SELECT l FROM Prestito l WHERE l.dataRestituzionePrevista < :currentDate and l.dataRestituzioneEffettiva is null")
})
public class Catalogo {
	@Id
	@Column(unique = true)
	private long isbn;
	
	private String titolo;
	@Column(name = "anno_pubblicazione")
	private Date annoPubblicazione;
	@Column(name = "numero_pagine")
	private int numeroPagine;
	public Catalogo(long isbn, String titolo, Date annopubblicazione, int numeroPagine) {
		this.isbn = isbn;
		this.titolo = titolo;
		this.annoPubblicazione = annopubblicazione;
		this.numeroPagine = numeroPagine;
	}
}
