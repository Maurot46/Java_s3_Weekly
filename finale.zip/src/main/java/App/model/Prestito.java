package App.model;

import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class Prestito {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@ManyToOne
	private Utenti utenti;
	@ManyToOne
	private Catalogo oggetto;
	@Column(name = "data_inizio")
	private Date dataInizio;
	@Column(name = "data_restituzione_prevista")
	private Calendar dataRestituzionePrevista;
	@Column(name = "data_restituzione_effettiva")
	private LocalDate dataRestituzioneEffettiva;
	
	public void restituzioneEffettiva(LocalDate dataRestituzioneEffettiva) {
        this.dataRestituzioneEffettiva = dataRestituzioneEffettiva;
    }
	
}
