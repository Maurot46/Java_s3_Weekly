package App.model.DAO;

import javax.persistence.EntityManager;

import App.model.Catalogo;
import App.util.JpaUtil;

public class CatalogoDAO {
	public Catalogo getByIsbn(Long isbn) {
		EntityManager em = JpaUtil.getEntityManagerFactory().createEntityManager();
		try {

			return em.find(Catalogo.class, isbn);

		} finally {
			em.close();
		}

	}
}
